//© KAGENOUDEV-2025
//===========================//
global.prefa = ["","!",".",",","🐤","🗿"]
global.owner = ["6285748533018"]
global.NamaOwner = "𝙇𝙔𝙉𝙀𝙓 𝙑1"
global.namabot = "𝙇𝙔𝙉𝙀𝙓 𝙑1"
//===========================//
//Global Mess
global.mess = {
 ingroup: "It's not funny, this feature is only for groups💢",
 admin: "not funny, only group admins use this feature💢",
 owner: "Wow! You're not my owner🗣️",
 premium: "you are not a premium user",
 success: 'Success bro✅',
}
//===========================//